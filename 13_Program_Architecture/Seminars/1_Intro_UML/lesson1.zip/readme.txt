/// https://www.diagrams.net/
/// https://github.com/jgraph/drawio-desktop/releases/tag/v20.3.0