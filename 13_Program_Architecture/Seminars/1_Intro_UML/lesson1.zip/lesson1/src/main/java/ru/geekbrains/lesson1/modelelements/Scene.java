package ru.geekbrains.lesson1.modelelements;

import java.util.Collection;

public class Scene {

    private int id;
    private Collection<PoligonalModel> models;
    private Collection<Flash> flashes;
    private Collection<Camera> cameras;

    //TODO: Добавить методы по добавлению моделей, света и камер

}
