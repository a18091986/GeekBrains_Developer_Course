package ru.geekbrains.lesson1;

import java.util.Date;

public class Buyer {

    private static int counter = 0;
    private final  int id;
    private String name;
    private String lastName;
    private String patronymic;
    private Date birthday;

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    {
        id = ++counter;
    }
}
