package ru.geekbrains.lesson1.inmemorymodel;

/**
 * Интерфейс наблюдателя (observer), наблюдатель подписывается на изменения ModelStore
 */
public interface ModelChangedObserver {

    void ApplyUpdateModel();
}
