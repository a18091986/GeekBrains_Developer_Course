package ru.geekbrains.lesson1.modelelements;

public class Flash {
    //TODO: Добавить реализацию
}
