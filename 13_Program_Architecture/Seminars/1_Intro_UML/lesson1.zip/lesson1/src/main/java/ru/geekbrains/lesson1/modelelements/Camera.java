package ru.geekbrains.lesson1.modelelements;


public class Camera {

    //TODO: Добавить реализацию
}
