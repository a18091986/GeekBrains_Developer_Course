package ru.geekbrains.lesson1.inmemorymodel;

public class Homework {

    public static void main(String[] args) {
        ModelStore modelStore = new ModelStore();
        //TODO: ...
        //TODO: Спроектировать класс-наблюдатель ( на базе интерфейса ModelChangedObserver)

    }

}
