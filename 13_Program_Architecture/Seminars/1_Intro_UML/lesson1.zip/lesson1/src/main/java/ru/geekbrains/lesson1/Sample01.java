package ru.geekbrains.lesson1;

import java.util.ArrayList;
import java.util.Collection;

public class Sample01 {

    public static void main(String[] args) {

        Store store = new Store();
        //TODO: ...

        MyLogObserver1 myLogObserver1 = new MyLogObserver1();
        MyLogObserver2 myLogObserver2 = new MyLogObserver2();


        MyLogFileWriter myLogFileWriter = new MyLogFileWriter();
        myLogFileWriter.registerObserver(myLogObserver1);
        myLogFileWriter.registerObserver(myLogObserver2);

        myLogFileWriter.writeString("Hello, GeekBrains!");

        myLogFileWriter.removeObserver(myLogObserver2);

        myLogFileWriter.writeString("Hello, GeekBrains!");

    }

}

class MyLogObserver1 implements FileObserver{

    public void UpdateState()
    {
        System.out.println("MyLogObserver1 -> Файл был изменен ...");
    }
}

class MyLogObserver2 implements FileObserver{

    public void UpdateState()
    {
        System.out.println("MyLogObserver2 -> Файл был изменен ...");
    }
}

interface FileObserver{
    void UpdateState();
}

class MyLogFileWriter implements FileChanger{

    private Collection<FileObserver> _observers = new ArrayList<>();

    @Override
    public void registerObserver(FileObserver o) {
        _observers.add(o);
    }

    @Override
    public void removeObserver(FileObserver o) {
        _observers.remove(o);
    }

    public void writeString(String str){
        //TODO: Запись строки в файл ...
        NotifyAll();
    }

    @Override
    public void NotifyAll() {
        for (FileObserver o : _observers){
            o.UpdateState();
        }
    }

}


interface FileChanger{

    void registerObserver(FileObserver o);
    void removeObserver(FileObserver o);

    void NotifyAll();

}