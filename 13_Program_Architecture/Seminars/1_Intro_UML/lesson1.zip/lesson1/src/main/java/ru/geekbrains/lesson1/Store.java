package ru.geekbrains.lesson1;

import java.util.Collection;
import java.util.HashSet;

public class Store {

    private Collection<Order> orders = new HashSet<>();

    public boolean AddOrder(Order order)
    {
        return true;
    }

    public boolean RemoveOrder(int id)
    {
        return true;
    }

    public boolean paymentOrder(int id)
    {
        return true;
    }


}
