package ru.geekbrains.lesson1.modelelements;

import java.util.Collection;

public class Poligon {

    private Collection<Point3D> points;

    public Collection<Point3D> getPoints() {
        return points;
    }

    public Poligon(Collection<Point3D> points) {
        //TODO: Контроль кол-ва точек ??? доработать
        this.points = points;
    }
}
