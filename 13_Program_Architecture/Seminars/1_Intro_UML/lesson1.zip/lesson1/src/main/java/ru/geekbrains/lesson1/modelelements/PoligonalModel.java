package ru.geekbrains.lesson1.modelelements;

public class PoligonalModel {
    //TODO: Добавить реализацию
}
