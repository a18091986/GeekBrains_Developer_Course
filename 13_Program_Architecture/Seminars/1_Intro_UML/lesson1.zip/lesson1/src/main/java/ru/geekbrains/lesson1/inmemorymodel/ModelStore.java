package ru.geekbrains.lesson1.inmemorymodel;

import java.util.ArrayList;
import java.util.Collection;

public class ModelStore implements  ModelChanger {

    //TODO: Протянуть оставшиеся поля

    private Collection<ModelChangedObserver> _observers = new ArrayList<>();

    @Override
    public void RegisterModelChanger(ModelChangedObserver o) {
        //TODO: ...
    }

    @Override
    public void RemoveModelChanger(ModelChangedObserver o) {
        //TODO: ...
    }

    @Override
    public void NotifyChange() {
        //TODO: ...
    }
}
